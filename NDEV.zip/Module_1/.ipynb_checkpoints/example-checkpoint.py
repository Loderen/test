from netmiko import Netmiko

leaf1_test = {
    "host": "172.20.20.11",
    "username": "admin",
    "password": "admin",
    "device_type": "arista_eos",
}

commands = ['show ip route']

with Netmiko(**leaf1_test) as leaf1:
    leaf1.enable()
    output = leaf1.send_config_set(commands)
    print(output)