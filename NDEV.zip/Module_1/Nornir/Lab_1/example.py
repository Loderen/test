import pyeapi

def patch_pyeapi_ciphers():

    try:
        import pyeapi.eapilib
    except ImportError:
        return

    connect_orig = pyeapi.eapilib.HttpsConnection.connect

    def connect(self):
        self._context.set_ciphers('DEFAULT@SECLEVEL=2')
        return connect_orig(self)

    pyeapi.eapilib.HttpsConnection.connect = connect

patch_pyeapi_ciphers()

###Start your code from here###

